package com.example.sample1

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.sample1.databinding.ActivityMain2Binding
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase


class MainActivity2 : AppCompatActivity() {

    private lateinit var binding: ActivityMain2Binding
    private lateinit var database: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMain2Binding.inflate(layoutInflater)
setContentView(binding.root)
binding.button.setOnClickListener {
    val username = binding.textInputEditText4.text.toString()
    val email = binding.textInputEditText.text.toString()
    val password = binding.textInputEditText2.text.toString()
    val confirmPassword = binding.textInputEditText3.text.toString()

    database = FirebaseDatabase.getInstance().getReference("Users")
    val users = User(username,email,password,confirmPassword)
    database.child(username).setValue(users).addOnSuccessListener {


        binding.textInputEditText4.text!!.clear()
        binding.textInputEditText.text!!.clear()
        binding.textInputEditText2.text!!.clear()
        binding.textInputEditText3.text!!.clear()

        Toast.makeText(this,"Successfully Saved",Toast.LENGTH_SHORT).show()

    }.addOnFailureListener {

        Toast.makeText(this,"Failed",Toast.LENGTH_SHORT).show()

    }
}
        setContentView(R.layout.activity_main2)
        val textView = findViewById<TextView>(R.id.textView9)
        textView.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

    }
}